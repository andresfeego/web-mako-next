import { getDB } from './GetDB';

export async function getEmpresas(busqueda, ciudad, categoria, signal, limInf = 0, limSup = 9000000000) {
  const options = {
    method: 'POST',
    body: {
      ciudad,
      busServicios: busqueda,
      busCategoria: categoria,
      limInf,
      limSup
    }
  };

  if (signal) options.signal = signal;

  return await getDB('/empresas', options);
}

export async function usuarioExiste(idUsuario) {
  const data = await getDB('/usuario/usuarioExiste/' + idUsuario, { method: 'GET' });
  return data && data.length > 0 ? data[0] : null;
}

export async function loginUsuario(correo, pass) {
  return await getDB('/usuario/loginUsuario', {
    method: 'POST',
    body: { correo, pass }
  });
}

export async function getRolesUsuario(idUser) {
  return await getDB('/usuario/rolesXid/' + idUser, { method: 'GET' });
}

export async function getUsuario(idUser) {
  const data = await getDB('/usuario/usuarioXid/' + idUser, { method: 'GET' });
  const userReturn = data && data.length > 0 ? data[0] : null;

  if (userReturn) {
    const rolesDB = await getRolesUsuario(idUser);
    if (rolesDB && rolesDB.length > 0) {
      userReturn.roles = rolesDB.map(r => r.id_rol);
      userReturn.rolesDB = rolesDB;
    } else {
      userReturn.roles = [5];
      userReturn.rolesDB = [5];
    }
  }

  return userReturn;
}
