import { setDB } from './SetDb';

export async function guardarBusquedaPalabra(palabra) {
  return await setDB('/bitacora/busquedaPalabra', {
    body: { palabra }
  });
}

export async function guardarComentario({ nombre, correo, mensaje }) {
  return await setDB('/comentarios/agregar', {
    body: { nombre, correo, mensaje }
  });
}

export async function guardarError(error) {
  return await setDB('/bitacora/errores', {
    body: error
  });
}

