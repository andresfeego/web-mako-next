const EmpresaTipoCero = () =>{
    return (
        <h1>empresa tipo 0</h1>
    )
}

export default EmpresaTipoCero