import styles from './PanelBusquedas.module.scss';

const PanelBusquedas = () => {
    return (
        <div className={styles.header}>
            <h1>PanelBusquedas</h1>

        </div>
    )
}

export default PanelBusquedas