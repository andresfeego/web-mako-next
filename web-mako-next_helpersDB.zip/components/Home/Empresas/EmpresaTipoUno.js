import BarraBusquedaEmpresa from "./Header/BarraBusquedaEmpresa"
import Header from "./Header/Header"

const EmpresaTipoUno = ({empresa, municipios, empresas, slides}) => {
    return (
        <div>
            
        </div>
    )
}

export default EmpresaTipoUno